const smallSize = 4.0;
const mediumSize = 8.0;
const largeSize = 16.0;
const extraLargeSize = 32.0;